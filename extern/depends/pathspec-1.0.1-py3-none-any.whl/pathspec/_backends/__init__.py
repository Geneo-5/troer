"""
WARNING: The *pathspec._backends* package is not part of the public API. Its
contents and structure are likely to change.
"""
