Cheetah\.SettingsManager module
===============================

.. automodule:: Cheetah.SettingsManager
    :members:
    :undoc-members:
    :show-inheritance:
